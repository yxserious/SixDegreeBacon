//
//  actorconnections.cpp
//  cse100pa4
//
//  Created by Kaijie Cai on 12/1/17.
//  Copyright © 2017 kj. All rights reserved.
//


#include <iostream>
#include <fstream>
#include <sstream>
#include <queue>
#include "ActorGraph.h"
using namespace std;

void reUnion(string actor, ActorNode* target,
             unordered_map<string, ActorNode*>* actorList){
    auto curSet = actorList->operator[](actor);
    while(curSet->prev != nullptr){
        auto prev = curSet;
        curSet = curSet->prev;
        prev->prev = target;
        
    }
}

string find(string actor, unordered_map<string, ActorNode*>* actorList){
    auto curSet = actorList->operator[](actor);
    while(curSet->prev != nullptr){
        curSet = curSet->prev;
      
    }
    reUnion(actor, curSet, actorList);
    
    return curSet->getName();
}

void unionNodes(string actor1, string actor2,
                unordered_map<string, ActorNode*>* actorList){
    string first_set = find(actor1, actorList);
    string second_set = find(actor2, actorList);
    if(first_set == second_set)
        return;
    actorList->operator[](first_set)->prev = actorList->operator[](second_set);

}

bool BFS(string end, string start, ActorGraph& actorGraph){
    
    auto actorlist = actorGraph.actorList;
    ActorNode* startActor = actorGraph.actorList[start];
    //mark all nodes as not visited
    for(auto cur = actorlist.begin(); cur != actorlist.end(); cur++){
        (*cur).second->clearVisited();
        (*cur).second->edge = "";
        (*cur).second->prev = nullptr;
        
    }
    
    
    
    
    queue<ActorNode*> queue;
    queue.push(startActor);
    while( !queue.empty()){
        ActorNode* curActor = queue.front();
        curActor->markVisited();
        vector<ActorEdge*>* edges = curActor->edges;
        for( auto curEdge = edges->begin(); curEdge != edges->end(); curEdge++){
            ActorEdge* edge = *curEdge;
            string neighbor_str = edge->second_end;
            ActorNode* neighbor = actorlist[neighbor_str];
            if( neighbor->isVisited() || neighbor->prev != nullptr)
                continue;
            //set prev and edge that connect two nodes
            neighbor->prev = curActor;
            neighbor->edge = edge->movie;
            if( neighbor->getName() == end)
                return true;
            //push
            queue.push(neighbor);
        }
        queue.pop();
    }
    
    return false;
}

vector<vector<string>> loadingFile(ifstream& infile){
    bool have_header = false;
    vector<vector<string>> pairs;
    while (infile) {
        string s;
        
        // get the next line
        if (!getline( infile, s )) break;
        
        if (!have_header) {
            // skip the header
            have_header = true;
            continue;
        }
        
        istringstream ss( s );
        vector <string> record;
        
        while (ss) {
            string next;
            
            // get the next string before hitting a tab character and put it in 'next'
            if (!getline( ss, next, '\t' )) break;
            
            record.push_back( next );
        }
        
        if (record.size() != 2) {
            // we should have exactly 3 columns
            continue;
        }
        
        pairs.push_back(record);
    }
    
    return pairs;
    
}

void print(string actor1, string actor2, int year, ofstream& out){
    out<<actor1<<"\t"<<actor2<<"\t"<<year<<endl;
    
}

void searching(string actor1, string actor2, ActorGraph& actorGraph,
               ofstream& out){
    auto actors = actorGraph.actorList;
    auto moviesList = actorGraph.sorted_moviesList;
    for(int k = 0; k < moviesList.size(); k++){
        auto movie = moviesList[k];
        
        auto actorsInMovie = movie->actors;
        for(int i = 1; i < actorsInMovie->size(); i++){
            unionNodes(actorsInMovie->operator[]((0)),
                       actorsInMovie->operator[](i),
                       &actors);
            
            if(find(actor1, &actors)== find(actor2, &actors)){
                print(actor1, actor2, movie->year,out);

                return;
            }
            
            
        }
        
    }
    print(actor1, actor2,9999,out);
}


void searchingBFS(string actor1, string actor2, ActorGraph& actorGraph,
                  ofstream& out){
    auto movies = actorGraph.sorted_moviesList;
    for(auto curMovie = movies.begin(); curMovie!= movies.end(); curMovie++){
        //actorslist in movie
        vector<string>* actors = (*curMovie)->actors;
        for(auto cur = actors->begin(); cur != actors->end(); cur++){
            for(auto next = actors->begin(); next!= actors->end(); next++){
                //calculate weight
                
                if(*cur != *next)
                {
                    int w_value = 1+ (2015 - (*curMovie)->year);
                    //make edge
                    string movie_name = (*curMovie)->getKey();
                    auto edge = new ActorEdge(*next, movie_name, w_value);
                    actorGraph.actorList[*cur]->edges->push_back(edge);
                }
            }
        }
        bool found = BFS(actor1, actor2, actorGraph);
        if(found)
        {
            cout<<actor1<<"\t"<<actor2<<"\t"<<(*curMovie)->year<<endl;
            //print(actor1,actor2,(*curMovie)->year,out);
            return ;
        }
    }
    print(actor1,actor2,9999,out);

}

int main(int argc, const char * argv[]){
    
    if( argc != 5){
        cout<<"incorrect number of args, 4 needed"<<endl;
        return 0;
    }

    string pair_actors_str =argv[2];
    string output_str = argv[3];
    string isUfind = argv[4];
    
    //open pair_actors file
    ifstream pair_actors(pair_actors_str);
    if(! pair_actors){
        cout<<"cannot open pair_actors file"<<endl;
        return 0;
    }
    
    if( isUfind !="ufind" && isUfind != "bfs"){
        cout<<"please select ufind or bfs"<<endl;
        return 0;
    }
    
    
    ActorGraph actorGraph;
    
    actorGraph.loadFromFile(argv[1], true);
    actorGraph.sortingMoviesList();
    auto pairs = loadingFile(pair_actors);
    ofstream outfile(output_str);
    
    
    if(isUfind == "ufind"){
       
        auto actorsList = actorGraph.actorList;
        outfile<<"Actor1\tAcotr2\tYear"<<endl;
        for(int n = 0; n < pairs.size(); n++){
            string actor1 = pairs[n][0];
            string actor2 = pairs[n][1];
            searching(actor1, actor2, actorGraph,outfile);
            
            
            for(auto cur = actorsList.begin(); cur != actorsList.end(); cur++){
                cur->second->prev = nullptr;
            }

        }
    }
    else{
        for(int i = 0; i< pairs.size();i++){
            searchingBFS(pairs[i][0], pairs[i][1], actorGraph, outfile);
            //all the actors, similar to actorgraph.cpp
            
            //for(auto cur = actorList.begin(); cur != actorList.end(); cur++){
            
            //movie is the one sorted by time order
            //looping through all the movies, stop if find
            
        }
    }
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    outfile.close();
    pair_actors.close();
    
    
    return 0;
}
